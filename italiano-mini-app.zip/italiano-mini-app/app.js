const tg = window.Telegram?.WebApp;
if (tg) {
  tg.ready();
  tg.expand();
  if (tg.setHeaderColor) tg.setHeaderColor('secondary_bg_color');
}

const verbs = [
  {
    infinitive: 'svegliarsi', ru: 'просыпаться', pronouns: 'mi · ti · si · ci · vi · si',
    forms: [['io','mi sveglio'],['tu','ti svegli'],['lui / lei','si sveglia'],['noi','ci svegliamo'],['voi','vi svegliate'],['loro','si svegliano']],
    exercises: [
      { ru:'Я просыпаюсь каждый день в семь.', accepted:['mi sveglio ogni giorno alle sette','ogni giorno mi sveglio alle sette','io mi sveglio ogni giorno alle sette'], model:'Mi sveglio ogni giorno alle sette.' },
      { ru:'По воскресеньям мы просыпаемся поздно.', accepted:['la domenica ci svegliamo tardi','di domenica ci svegliamo tardi','noi ci svegliamo tardi la domenica'], model:'La domenica ci svegliamo tardi.' },
      { ru:'Во сколько ты просыпаешься?', accepted:['a che ora ti svegli','a che ora ti svegli?'], model:'A che ora ti svegli?' }
    ]
  },
  {
    infinitive:'alzarsi', ru:'вставать', pronouns:'mi · ti · si · ci · vi · si',
    forms:[['io','mi alzo'],['tu','ti alzi'],['lui / lei','si alza'],['noi','ci alziamo'],['voi','vi alzate'],['loro','si alzano']],
    exercises:[
      { ru:'Я встаю в восемь.', accepted:['mi alzo alle otto','io mi alzo alle otto'], model:'Mi alzo alle otto.' },
      { ru:'Они встают очень рано.', accepted:['si alzano molto presto','loro si alzano molto presto'], model:'Si alzano molto presto.' }
    ]
  },
  {
    infinitive:'lavarsi', ru:'мыться / умываться', pronouns:'mi · ti · si · ci · vi · si',
    forms:[['io','mi lavo'],['tu','ti lavi'],['lui / lei','si lava'],['noi','ci laviamo'],['voi','vi lavate'],['loro','si lavano']],
    exercises:[
      { ru:'Ты умываешься утром.', accepted:['ti lavi la mattina','tu ti lavi la mattina','ti lavi al mattino'], model:'Ti lavi la mattina.' },
      { ru:'Мы моемся перед ужином.', accepted:['ci laviamo prima di cena','noi ci laviamo prima di cena'], model:'Ci laviamo prima di cena.' }
    ]
  }
];

let verbIndex = 0;
let exerciseIndex = 0;

const conjugation = document.getElementById('conjugation');
const promptEl = document.getElementById('prompt');
const answer = document.getElementById('answer');
const feedback = document.getElementById('feedback');
const actions = document.getElementById('actions');
const checkBtn = document.getElementById('checkBtn');
const progress = document.getElementById('progress');

function normalize(s) {
  return s.trim().toLowerCase().replace(/[.!?;,]/g,'').replace(/\s+/g,' ');
}

function renderVerb() {
  const v = verbs[verbIndex];
  document.querySelector('.verb').textContent = v.infinitive;
  document.querySelector('.translation').textContent = v.ru;
  document.querySelector('.pronouns').textContent = v.pronouns;
  conjugation.innerHTML = v.forms.map(([p,f]) => `<div class="row"><div class="person">${p}</div><div class="form">${f}</div></div>`).join('');
  progress.textContent = `${verbIndex + 1} / ${verbs.length}`;
  renderExercise();
}

function renderExercise() {
  const e = verbs[verbIndex].exercises[exerciseIndex];
  promptEl.textContent = e.ru;
  answer.value = '';
  feedback.className = 'feedback hidden';
  actions.classList.add('hidden');
  checkBtn.classList.remove('hidden');
  answer.focus();
}

function analyze(raw, exercise, verb) {
  const n = normalize(raw);
  const accepted = exercise.accepted.map(normalize);
  if (accepted.includes(n)) return { type:'good', title:'✓ Отлично', text:'Фраза грамматически корректна и звучит естественно.' };

  const expectedReflexives = ['mi','ti','si','ci','vi'];
  const hasReflexive = expectedReflexives.some(p => n.split(' ').includes(p));
  const stem = verb.infinitive.replace('si','').slice(0,4);
  const looksLikeVerb = n.includes(stem);

  if (looksLikeVerb && !hasReflexive) {
    return { type:'almost', title:'△ Почти', text:'Похоже, ты выбрал правильный глагол, но пропустил возвратное местоимение.', correction:`Вариант: ${exercise.model}` };
  }

  const answerWords = new Set(n.split(' '));
  const modelWords = normalize(exercise.model).split(' ');
  const overlap = modelWords.filter(w => answerWords.has(w)).length / modelWords.length;
  if (overlap >= .45) {
    return { type:'almost', title:'△ Уже близко', text:'Смысл понятен, но форма глагола или порядок слов требуют правки.', correction:`Естественный вариант: ${exercise.model}` };
  }

  return { type:'bad', title:'✕ Давай разберём', text:'Попробуй ещё раз обратить внимание на лицо и возвратное местоимение.', correction:`Правильный вариант: ${exercise.model}` };
}

checkBtn.addEventListener('click', () => {
  if (!answer.value.trim()) { answer.focus(); return; }
  const v = verbs[verbIndex];
  const e = v.exercises[exerciseIndex];
  const result = analyze(answer.value, e, v);
  feedback.className = `feedback ${result.type}`;
  feedback.innerHTML = `<strong>${result.title}</strong>${result.text}${result.correction ? `<div class="correction">${result.correction}</div>` : ''}`;
  actions.classList.remove('hidden');
  checkBtn.classList.add('hidden');
  tg?.HapticFeedback?.notificationOccurred(result.type === 'good' ? 'success' : 'warning');
});

document.getElementById('sameVerbBtn').addEventListener('click', () => {
  exerciseIndex = (exerciseIndex + 1) % verbs[verbIndex].exercises.length;
  renderExercise();
});

document.getElementById('newVerbBtn').addEventListener('click', () => {
  verbIndex = (verbIndex + 1) % verbs.length;
  exerciseIndex = 0;
  renderVerb();
});

document.getElementById('prevVerbBtn').addEventListener('click', () => {
  verbIndex = (verbIndex - 1 + verbs.length) % verbs.length;
  exerciseIndex = 0;
  renderVerb();
});

answer.addEventListener('keydown', (e) => {
  if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') checkBtn.click();
});

renderVerb();
